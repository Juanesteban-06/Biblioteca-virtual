package biblioteca;

import java.util.List;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Biblioteca biblioteca = new Biblioteca();

        System.out.println("¡Bienvenido a la Biblioteca Virtual!");

        int opcion;
        
        do {
            System.out.println("\n--- Menú Principal ---");
            System.out.println("1. Registrar nuevo usuario");
            System.out.println("2. Agregar nuevo libro");
            System.out.println("3. Buscar libros");
            System.out.println("4. Prestar libro");
            System.out.println("5. Devolver libro");
            System.out.println("6. Mostrar libros disponibles");
            System.out.println("7. Mostrar libros prestados");
            System.out.println("0. Salir y Guardar Cambios"); 
            System.out.print("Ingrese su opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); 

            try {
                switch (opcion) {
                    case 1:
                        System.out.print("Ingrese el nombre del usuario: ");
                        String nombreUsuario = scanner.nextLine();
                        System.out.print("Ingrese el DNI del usuario: ");
                        String dniUsuario = scanner.nextLine();
                        biblioteca.registrarUsuario(new Usuario(nombreUsuario, dniUsuario));
                        break;
                    case 2:
                        System.out.print("Ingrese el título del libro: ");
                        String tituloLibro = scanner.nextLine();
                        System.out.print("Ingrese el autor del libro: ");
                        String autorLibro = scanner.nextLine();
                        System.out.print("Ingrese el ISBN del libro: ");
                        String isbnLibro = scanner.nextLine();
                        biblioteca.agregarLibro(new Libro(tituloLibro, autorLibro, isbnLibro, "Disponible"));
                        break;
                    case 3:
                        System.out.print("Ingrese el criterio de búsqueda (título, autor o ISBN): ");
                        String criterioBusqueda = scanner.nextLine();
                        List<Libro> resultadosBusqueda = biblioteca.buscarLibros(criterioBusqueda);
                        if (resultadosBusqueda.isEmpty()) {
                            System.out.println("No se encontraron libros que coincidan con el criterio.");
                        } else {
                            System.out.println("--- Resultados de Búsqueda ---");
                            resultadosBusqueda.forEach(System.out::println);
                        }
                        break;
                    case 4:
                        System.out.print("Ingrese el ISBN del libro a prestar: ");
                        String isbnPrestamo = scanner.nextLine();
                        System.out.print("Ingrese el DNI del usuario que presta: ");
                        String dniPrestamo = scanner.nextLine();
                        biblioteca.prestarLibro(isbnPrestamo, dniPrestamo);
                        break;
                    case 5:
                        System.out.print("Ingrese el ISBN del libro a devolver: ");
                        String isbnDevolucion = scanner.nextLine();
                        System.out.print("Ingrese el DNI del usuario que devuelve: ");
                        String dniDevolucion = scanner.nextLine();
                        biblioteca.devolverLibro(isbnDevolucion, dniDevolucion);
                        break;
                    case 6:
                        System.out.println("--- Libros Disponibles ---");
                        List<Libro> disponibles = biblioteca.mostrarLibrosDisponibles();
                        if (disponibles.isEmpty()) {
                            System.out.println("No hay libros disponibles en este momento.");
                        } else {
                            disponibles.forEach(System.out::println);
                        }
                        break;
                    case 7:
                        System.out.println("--- Libros Prestados ---");
                        List<Libro> prestados = biblioteca.mostrarLibrosPrestados();
                        if (prestados.isEmpty()) {
                            System.out.println("No hay libros prestados en este momento.");
                        } else {
                            prestados.forEach(System.out::println);
                        }
                        break;
                    case 0: 
                        System.out.println("Saliendo de la Biblioteca Virtual. ¡Hasta pronto!");
                        break;
                    default:
                        System.out.println("Opción no válida. Por favor, intente de nuevo.");
                }
            } catch (BibliotecaException e) {
                System.err.println("Error de la biblioteca: " + e.getMessage());
            } catch (Exception e) {
                System.err.println("Ha ocurrido un error inesperado: " + e.getMessage());
                e.printStackTrace();
            }
        } while (opcion != 0); 

        biblioteca.guardarDatos();
        scanner.close(); 
    }
}