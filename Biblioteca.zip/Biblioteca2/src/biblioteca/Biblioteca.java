package biblioteca;

import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class Biblioteca {
    private Map<String, Libro> catalogo; 
    private Map<String, Usuario> usuarios; 
    private static final String LIBROS_FILE = "libros.txt";
    private static final String USUARIOS_FILE = "usuarios.txt";

    public Biblioteca() {
        this.catalogo = new HashMap<>();
        this.usuarios = new HashMap<>();
        cargarDatos(); 
    }


    private void cargarDatos() {
        System.out.println("Cargando datos de libros...");
        try (BufferedReader br = new BufferedReader(new FileReader(LIBROS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                Libro libro = Libro.fromFileString(line);
                if (libro != null) {
                    catalogo.put(libro.getIsbn(), libro);
                }
            }
            System.out.println("Libros cargados: " + catalogo.size());
        } catch (FileNotFoundException e) {
            System.out.println("Archivo de libros no encontrado. Se creará uno nuevo al guardar.");
        } catch (IOException e) {
            System.err.println("Error al leer el archivo de libros: " + e.getMessage());
        }

        System.out.println("Cargando datos de usuarios...");
        try (BufferedReader br = new BufferedReader(new FileReader(USUARIOS_FILE))) {
            String line;
            while ((line = br.readLine()) != null) {
                Usuario usuario = Usuario.fromFileString(line);
                if (usuario != null) {
                    usuarios.put(usuario.getDni(), usuario);
                }
            }
            System.out.println("Usuarios cargados: " + usuarios.size());
        } catch (FileNotFoundException e) {
            System.out.println("Archivo de usuarios no encontrado. Se creará uno nuevo al guardar.");
        } catch (IOException e) {
            System.err.println("Error al leer el archivo de usuarios: " + e.getMessage());
        }
    }

    public void guardarDatos() {
        System.out.println("Guardando datos de libros...");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(LIBROS_FILE))) {
            for (Libro libro : catalogo.values()) {
                bw.write(libro.toFileString());
                bw.newLine();
            }
            System.out.println("Libros guardados exitosamente.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo de libros: " + e.getMessage());
        }

        System.out.println("Guardando datos de usuarios...");
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(USUARIOS_FILE))) {
            for (Usuario usuario : usuarios.values()) {
                bw.write(usuario.toFileString());
                bw.newLine();
            }
            System.out.println("Usuarios guardados exitosamente.");
        } catch (IOException e) {
            System.err.println("Error al escribir en el archivo de usuarios: " + e.getMessage());
        }
    }

    

    public void agregarLibro(Libro libro) throws BibliotecaException {
        if (catalogo.containsKey(libro.getIsbn())) {
            throw new BibliotecaException("El libro con ISBN " + libro.getIsbn() + " ya existe en el catálogo.");
        }
        catalogo.put(libro.getIsbn(), libro);
        System.out.println("Libro agregado: " + libro.getTitulo());
    }

    public void registrarUsuario(Usuario usuario) throws BibliotecaException {
        if (usuarios.containsKey(usuario.getDni())) {
            throw new BibliotecaException("El usuario con DNI " + usuario.getDni() + " ya está registrado.");
        }
        usuarios.put(usuario.getDni(), usuario);
        System.out.println("Usuario registrado: " + usuario.getNombre());
    }

    public List<Libro> buscarLibros(String criterio) {
        String lowerCaseCriterio = criterio.toLowerCase();
        return catalogo.values().stream()
                .filter(libro -> libro.getTitulo().toLowerCase().contains(lowerCaseCriterio) ||
                                 libro.getAutor().toLowerCase().contains(lowerCaseCriterio) ||
                                 libro.getIsbn().toLowerCase().contains(lowerCaseCriterio))
                .collect(Collectors.toList());
    }

    public void prestarLibro(String isbnLibro, String dniUsuario) throws BibliotecaException {
        Libro libro = catalogo.get(isbnLibro);
        Usuario usuario = usuarios.get(dniUsuario);

        if (libro == null) {
            throw new BibliotecaException("Libro con ISBN " + isbnLibro + " no encontrado.");
        }
        if (usuario == null) {
            throw new BibliotecaException("Usuario con DNI " + dniUsuario + " no encontrado.");
        }
        if (!libro.getEstado().equals("Disponible")) {
            throw new BibliotecaException("El libro '" + libro.getTitulo() + "' no está disponible para préstamo.");
        }
        if (usuario.getPrestamosIsbn().size() >= 3) {
            throw new BibliotecaException("El usuario '" + usuario.getNombre() + "' ha alcanzado el límite de 3 préstamos.");
        }

        libro.setEstado("Prestado");
        usuario.addPrestamo(isbnLibro);
        System.out.println("Libro '" + libro.getTitulo() + "' prestado a '" + usuario.getNombre() + "'.");
    }

    public void devolverLibro(String isbnLibro, String dniUsuario) throws BibliotecaException {
        Libro libro = catalogo.get(isbnLibro);
        Usuario usuario = usuarios.get(dniUsuario);

        if (libro == null) {
            throw new BibliotecaException("Libro con ISBN " + isbnLibro + " no encontrado.");
        }
        if (usuario == null) {
            throw new BibliotecaException("Usuario con DNI " + dniUsuario + " no encontrado.");
        }
        if (!libro.getEstado().equals("Prestado")) {
            throw new BibliotecaException("El libro '" + libro.getTitulo() + "' no está actualmente prestado.");
        }
        if (!usuario.getPrestamosIsbn().contains(isbnLibro)) {
            throw new BibliotecaException("El usuario '" + usuario.getNombre() + "' no tiene prestado el libro '" + libro.getTitulo() + "'.");
        }

        libro.setEstado("Disponible");
        usuario.removePrestamo(isbnLibro);
        System.out.println("Libro '" + libro.getTitulo() + "' devuelto por '" + usuario.getNombre() + "'.");
    }

    public List<Libro> mostrarLibrosDisponibles() {
        return catalogo.values().stream()
                .filter(libro -> libro.getEstado().equals("Disponible"))
                .collect(Collectors.toList());
    }

    public List<Libro> mostrarLibrosPrestados() {
        return catalogo.values().stream()
                .filter(libro -> libro.getEstado().equals("Prestado"))
                .collect(Collectors.toList());
    }

    
    public Libro getLibroByIsbn(String isbn) {
        return catalogo.get(isbn);
    }
}