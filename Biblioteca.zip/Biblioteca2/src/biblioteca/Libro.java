package biblioteca;

public class Libro {
	private String titulo;
    private String autor;
    private String isbn;
    private String estado;
    
    public Libro(String titulo, String autor, String isbn, String estado) {
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.estado = estado;
    }

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		this.titulo = titulo;
	}

	public String getAutor() {
		return autor;
	}

	public void setAutor(String autor) {
		this.autor = autor;
	}

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}
	public String toString() {
        return "Título: '" + titulo + '\'' +
               ", Autor: '" + autor + '\'' +
               ", ISBN: '" + isbn + '\'' +
               ", Estado: '" + estado + '\'';
    }
    
	public String toFileString() {
        return titulo + "|" + autor + "|" + isbn + "|" + estado;
    }

   
    public static Libro fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length == 4) {
            return new Libro(parts[0], parts[1], parts[2], parts[3]);
        }
        return null; 
    }
}
    
    




