package biblioteca;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;




public class Usuario {
	
	private String nombre;
    private String dni;
    private List<String> prestamosIsbn;
    
    
    public Usuario(String nombre, String dni) {
        this.nombre = nombre;
        this.dni = dni;
        this.prestamosIsbn = new ArrayList<>();
    }


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getDni() {
		return dni;
	}


	public void setDni(String dni) {
		this.dni = dni;
	}


	public List<String> getPrestamosIsbn() {
		return prestamosIsbn;
	}


	public void setPrestamosIsbn(List<String> prestamosIsbn) {
		this.prestamosIsbn = prestamosIsbn;
	}
	public void addPrestamo(String isbn) {
        this.prestamosIsbn.add(isbn);
    }

    public void removePrestamo(String isbn) {
        this.prestamosIsbn.remove(isbn);
    }
    
    public String toString() {
        return "Usuario: '" + nombre + '\'' +
               ", DNI: '" + dni + '\'' +
               ", Préstamos: " + prestamosIsbn.size() + " libros";
    }

        public String toFileString() {
        String prestamos = prestamosIsbn.stream().collect(Collectors.joining(","));
        return nombre + "|" + dni + "|" + prestamos;
    }

    
    public static Usuario fromFileString(String line) {
        String[] parts = line.split("\\|");
        if (parts.length >= 2) {
            Usuario usuario = new Usuario(parts[0], parts[1]);
            if (parts.length > 2 && !parts[2].isEmpty()) {
                String[] isbns = parts[2].split(",");
                for (String isbn : isbns) {
                    usuario.addPrestamo(isbn);
                }
            }
            return usuario;
        }
        return null;
    }
}
    
    

